from turtle import *
#blue circle
color('blue')
pensize(3)
circle(80)
penup() 
setposition(0, -160)
pendown() 
circle(80)
penup() 
setposition(80, -80)
pendown() 
circle(80)
penup() 
setposition(-80, -80)
pendown() 
circle(80)
#red circle
setheading(30)
color('red')
penup() 
setposition(0, 0)
pendown()
circle(80)

setheading(120)

circle(80)

setheading(210)

circle(80)


setheading(300)

circle(80)
#green circle
setheading(60)
color('green')

circle(80)

setheading(150)

circle(80)

setheading(240)

circle(80)


setheading(330)

circle(80)
done()

