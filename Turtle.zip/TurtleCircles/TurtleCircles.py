from turtle import *
pensize(3)
count = 0
for i in range(0, 360, 30):
	setheading(i)
	if count == 0:
		color('blue')
		circle(80)
		count = 1
		continue
	if count == 1:
		color('red')
		circle(80)
		count = 2
		continue
	if count == 2:
		color('green')
		circle(80)
		count = 0
		continue
done()
