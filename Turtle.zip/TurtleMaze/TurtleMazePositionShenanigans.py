from turtle import *
pensize(10)
penup()
setposition(300, -300)
pendown()
a = 300
b = 300
i = 300
while i > 0:
	b = i
	setposition(a,b)
	i = i - 5
	a = i
	setposition(-a,b)
	i = i - 5
	b = i
	setposition(-a,-b)
	i = i - 5
	a = i
	setposition(a,-b)
	i = i - 5
done()

