from turtle import *
pensize(5)
penup()
setposition(150, -150)
pendown()
color('brown')
distance = 300
decrease = 5
angle = 90

while distance > 0:
	setheading(angle)
	forward(distance)
	angle = angle + 90
	distance = distance - decrease
	
done()

