from turtle import *

distance = 350
angle = 0
speed(10)
while distance > 5:
	for i in range(0, 4):
		setheading(angle)
		forward(distance)
		angle = angle + 90
	angle = angle + 10
	distance = distance * 0.97
done()

	
	
	

