from turtle import *
from random import *

for angle in range(0, 360, randint(1,3)):
	forward (randint(1, 350))
	setposition(0,0)
	setheading(angle)
done()
