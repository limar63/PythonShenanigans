from turtle import *
distance = 200
speed(10)
while distance > 0:
	forward(distance)
	left(91)
	distance = distance -1
done()
	
	
	

